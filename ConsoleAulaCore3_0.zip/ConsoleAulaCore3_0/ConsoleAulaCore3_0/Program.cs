﻿using System;
using System.Collections.Generic;
using System.Reflection;
using System.Text.Json;

namespace ConsoleAulaCore3_0
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World valdir ;)");
        }

               

        /// <summary>
        /// Suporte interno rápido a JSON
        /// </summary>
        /// <param name="dataUtf8"></param>
        public static void Utf8JsonReaderLoop(ReadOnlySpan<byte> dataUtf8)
        {
            var json = new Utf8JsonReader(dataUtf8, isFinalBlock: true, state: default);

            while (json.Read())
            {
                JsonTokenType tokenType = json.TokenType;
                ReadOnlySpan<byte> valueSpan = json.ValueSpan;
                switch (tokenType)
                {
                    case JsonTokenType.StartObject:
                    case JsonTokenType.EndObject:
                        break;
                    case JsonTokenType.StartArray:
                    case JsonTokenType.EndArray:
                        break;
                    case JsonTokenType.PropertyName:
                        break;
                    case JsonTokenType.String:
                        string valueString = json.GetStringValue();
                        break;
                    case JsonTokenType.Number:
                        if (!json.TryGetInt32Value(out int valueInteger))
                        {
                            throw new FormatException();
                        }
                        break;
                    case JsonTokenType.True:
                    case JsonTokenType.False:
                        bool valueBool = json.GetBooleanValue();
                        break;
                    case JsonTokenType.Null:
                        break;
                    default:
                        throw new ArgumentException();
                }
            }

            dataUtf8 = dataUtf8.Slice((int)json.BytesConsumed);
            JsonReaderState state = json.CurrentState;
        }


        /// <summary>
        /// Intervalos e índices
        /// </summary>
        public static void Indices()
        {
            Index i1 = 3;  // number 3 from beginning

          /*Somente funciona para o C# 8*/
            Index i2 = ^4; // number 4 from end
            int[] a = { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9 };
            Console.WriteLine($"{a[i1]}, {a[i2]}"); // "3, 6"
        }

        /// <summary>
        /// Fluxo Assincronos
        /// </summary>
        /// <returns></returns>
        async IAsyncEnumerable<int> GetBigResultsAsync()
        {
            //await foreach (var result in GetResultsAsync())
            //{
            //    if (result > 20) yield return result;
            //}
           
        }



        /// <summary>
        /// Tipo: MetadataLoadContext
        /// </summary>
        public static void MetadataLoad()
        {
            var paths = new string[] { @"C:\myapp\mscorlib.dll", @"C:\myapp\myapp.dll" };
            var resolver = new PathAssemblyResolver(paths);
            using (var lc = new MetadataLoadContext(resolver))
            {
                Assembly a = lc.LoadFromAssemblyName("myapp");
                Type myInterface = a.GetType("MyApp.IPluginInterface");
                foreach (Type t in a.GetTypes())
                {
                    if (t.IsClass && myInterface.IsAssignableFrom(t))
                        Console.WriteLine($"Class {t.FullName} implements IPluginInterface");
                }
            }
        }

    }
}
