﻿namespace ConsoleAulaCore3_0
{
    internal class key
    {
    }
}