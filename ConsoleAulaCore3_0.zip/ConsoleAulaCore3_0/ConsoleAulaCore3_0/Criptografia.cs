﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;

namespace ConsoleAulaCore3_0
{
    public class Criptografia
    {
        /// <summary>
        /// Criptografia
        /// </summary>
        public void NewCrip()
        {

            // key should be: pre-known, derived, or transported via another channel, such as RSA encryption
            byte[] key = new byte[16];
            RandomNumberGenerator.Fill(key);

            byte[] nonce = new byte[12];
            RandomNumberGenerator.Fill(nonce);

            // normally this would be your data
            byte[] dataToEncrypt = new byte[1234];
            byte[] associatedData = new byte[333];
            RandomNumberGenerator.Fill(dataToEncrypt);
            RandomNumberGenerator.Fill(associatedData);

            // these will be filled during the encryption
            byte[] tag = new byte[16];
            byte[] ciphertext = new byte[dataToEncrypt.Length];

            using (AesGcm aesGcm = new AesGcm(key))
            {
                aesGcm.Encrypt(nonce, dataToEncrypt, ciphertext, tag, associatedData);
            }

            // tag, nonce, ciphertext, associatedData should be sent to the other part

            byte[] decryptedData = new byte[ciphertext.Length];

            using (AesGcm aesGcm = new AesGcm(key))
            {
                aesGcm.Decrypt(nonce, ciphertext, tag, decryptedData, associatedData);
            }

            // do something with the data
            // this should always print that data is the same
            Console.WriteLine($"AES-GCM: Decrypted data is{(dataToEncrypt.SequenceEqual(decryptedData) ? "the same as" : "different than")} original data.");

        }


        /// <summary>
        /// mportar/exportar chave de criptografia
        /// </summary>
        public void ImportExportCriptografia(string[] args)
        {
            using (RSA rsa = RSA.Create())
            {
                byte[] keyBytes = File.ReadAllBytes(args[0]);
                rsa.ImportRSAPrivateKey(keyBytes, out int bytesRead);

                Console.WriteLine($"Read {bytesRead} bytes, {keyBytes.Length - bytesRead} extra byte(s) in file.");
                RSAParameters rsaParameters = rsa.ExportParameters(true);
                Console.WriteLine(BitConverter.ToString(rsaParameters.D));
            }

        }



//Saida Console 
//user @comp-ubuntu1810:~/rsakeyprint$ echo Making a small key to save on screen space.
//Making a small key to save on screen space.
//user @comp-ubuntu1810:~/rsakeyprint$ openssl genrsa 768 | openssl rsa -outform der -out rsa.key
//Generating RSA private key, 768 bit long modulus(2 primes)
//..+++++++
//........+++++++
//e is 65537 (0x010001)
//writing RSA key
//user@comp-ubuntu1810:~/rsakeyprint$ dotnet run rsa.key
//Read 461 bytes, 0 extra byte (s) in file.
//0F-D0-82-34-F8-13-38-4A-7F-C7-52-4A-F6-93-F8-FB-6D-98-7A-6A-04-3B-BC-35-8C-7D-AC-A5-A3-6E-AD-C1-66-30-81-2C-2A-DE-DA-60-03-6A-2C-D9-76-15-7F-61-97-57-
//79-E1-6E-45-62-C3-83-04-97-CB-32-EF-C5-17-5F-99-60-92-AE-B6-34-6F-30-06-03-AC-BF-15-24-43-84-EB-83-60-EF-4D-3B-BD-D9-5D-56-26-F0-51-CE-F1
//user@comp-ubuntu1810:~/rsakeyprint$ openssl rsa -in rsa.key -inform der -text -noout | grep -A7 private
//privateExponent:
//0f:d0:82:34:f8:13:38:4a:7f:c7:52:4a:f6:93:f8:
//fb:6d:98:7a:6a:04:3b:bc:35:8c:7d:ac:a5:a3:6e:
//ad:c1:66:30:81:2c:2a:de:da:60:03:6a:2c:d9:76:
//15:7f:61:97:57:79:e1:6e:45:62:c3:83:04:97:cb:
//32:ef:c5:17:5f:99:60:92:ae:b6:34:6f:30:06:03:
//ac:bf:15:24:43:84:eb:83:60:ef:4d:3b:bd:d9:5d:
//56:26:f0:51:ce:f1


    }
}
