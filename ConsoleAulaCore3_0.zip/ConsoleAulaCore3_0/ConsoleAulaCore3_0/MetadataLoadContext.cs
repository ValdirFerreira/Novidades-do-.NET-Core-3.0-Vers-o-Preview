﻿using System;
using System.Reflection;

namespace ConsoleAulaCore3_0
{
    internal class MetadataLoadContext : IDisposable
    {
        private PathAssemblyResolver resolver;

        public MetadataLoadContext(PathAssemblyResolver resolver)
        {
            this.resolver = resolver;
        }

        internal Assembly LoadFromAssemblyName(string v)
        {
            throw new NotImplementedException();
        }
    }
}