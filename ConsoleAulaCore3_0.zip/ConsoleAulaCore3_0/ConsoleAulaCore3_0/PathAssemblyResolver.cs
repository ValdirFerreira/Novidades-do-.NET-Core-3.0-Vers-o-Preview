﻿namespace ConsoleAulaCore3_0
{
    internal class PathAssemblyResolver
    {
        private string[] paths;

        public PathAssemblyResolver(string[] paths)
        {
            this.paths = paths;
        }
    }
}